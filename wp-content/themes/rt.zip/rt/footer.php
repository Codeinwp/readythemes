</div>
<!-- End Wrapper -->

<!-- footer -->
<div id="footer">
    <div class="container_12">
        
        <!-- footer column 1 -->
        <div class="grid_3">
            <h4>
                About Ready Themes
            </h4>
            <p>
                We design and develop Wordpress themes for those interested in earning money online. 
				All of our themes are researched and tested for the best possible results.  <a href="/about/">Learn more</a> about how Ready Themes got started. 
            </p>
			<p>
			<a href="/features/">View our theme features</a>
			</p>
        </div>
        <!-- end footer column 1 -->
        
        <!-- footer column 2 -->
        <div class="grid_3">
            <h4>
                Site Links
            </h4>
            <ul>
				<li><a href="/affiliates/" rel="nofollow">Affiliate Program</a></li>
				<li><a href="/category/blog/">Blog</a></li>
				<li><a href="/category/themes/">Wordpress Themes</a></li>
				<li><a href="/faq/" >Frequently Asked Questions</a></li>
				<li><a href="/terms/" rel="nofollow">Terms</a></li>
				<li><a href="/privacy/" rel="nofollow">Privacy Policy</a></li>
			</ul>
        </div>
        <!-- end footer column 2 -->
        
        <!-- footer column 3 -->
        <div class="grid_3">
            <h4>
                Support
            </h4>
            <p>
				We support all of our premium themes for those who have purchased them. 
				If you are in need of support, please open a <a href="/support/">support ticket</a> and we'll do our best to help.
            </p>
			<p>
				<a href="/support/" rel="nofollow">Click here to open a support ticket &raquo;</a>
			</p>
        </div>
        <!-- end footer column 3 -->
        
        <!-- footer column 4 -->
        <div class="grid_3">
            <h4>
                Connect
            </h4>
            <p>
                Stay up to date by following us on social networking platforms or subscribe to our newsletter.
            </p>
            <p>
				<form method="post" class="af-form-wrapper" action="http://www.aweber.com/scripts/addlead.pl"  >
				<input type="hidden" name="meta_web_form_id" value="569774437" />
				<input type="hidden" name="meta_split_id" value="" />
				<input type="hidden" name="listname" value="readythemes" />
				<input type="hidden" name="redirect" value="http://www.aweber.com/thankyou-coi.htm?m=text" id="redirect_026c628723444f54bec76a11da42933a" />
				
				<input type="hidden" name="meta_adtracking" value="Basic_Form" />
				<input type="hidden" name="meta_message" value="1" />
				<input type="hidden" name="meta_required" value="email" />
				
				<input type="hidden" name="meta_tooltip" value="" />
					<div class="form_field">
						<input class="newsletter_input" id="awf_field-38946378" type="text" name="email" onblur="if (this.value==''){this.value='Enter Your Email'};" onfocus="if(this.value=='Enter Your Email'){this.value=''};" value="Enter Your Email" />						
						<input class="newsletter_submit" type="submit">
                        <img src="http://forms.aweber.com/form/displays.htm?id=rGyc7OwsLMzs" alt="" />
					</div><!--/form field-->
				</form>
            </p>
        </div>
        <!-- end footer column 4 -->
        <div class="clear"></div>
        <!-- end of grid row -->
        </div>
        <!-- end of grid row -->
    </div>
</div>
<!-- end footer -->
<div class="footer-bottom">
	<div class="container_12">
		<div style="float:left; width:400px; margin-left:10px;">Copyright &copy; <?php echo date("Y"); ?> Ready Themes</div>
		<div style="float:right; width:400px; text-align:right; margin-right:10px;"><a href="#top" class="scroll"><img src="<?php bloginfo('template_directory'); ?>/images/top.png" border="0" /></a></div>
		<div class="clear"></div>
	</div>
</div>

<?php wp_footer(); ?>
<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//cdn.zopim.com/?1JbsUYMbjtMOwoAxW8L3gukRyuZRHuTo';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script type="text/javascript">
adroll_adv_id = "F6CXQ6Y345ELXLTWJIG4YF";
adroll_pix_id = "BV7CZCGO4VFDJOO4HRRWLW";
(function () {
var oldonload = window.onload;
window.onload = function(){
   __adroll_loaded=true;
   var scr = document.createElement("script");
   var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
   scr.setAttribute('async', 'true');
   scr.type = "text/javascript";
   scr.src = host + "/j/roundtrip.js";
   ((document.getElementsByTagName('head') || [null])[0] ||
    document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
   if(oldonload){oldonload()}};
}());

jQuery(document).ready(function() {
    jQuery(':image').click(function() {
 
         _gaq.push(['_trackEvent', 'Click cumpara', jQuery(this).attr("src"), window.location.pathname]);

    
});
})
</script>

</body>
</html>