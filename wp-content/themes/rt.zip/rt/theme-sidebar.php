<div id="widget">

	<p>Purchase any of our professionally designed themes for only</p>
	<p style="font-size:24px; font-weight:bold;">$30</p>
	
</div>

<div id="widgetheading">Categories</div>
<div id="widget">

	<ul>
		<?php wp_list_categories('orderby=id&show_count=1&use_desc_for_title=0&child_of='.$cat); ?>
	</ul>

</div>